import matplotlib.pyplot as plt

# Define the data
data = {
    'AAPL_BKN2': -27.265625, 'ABCREPL_BHDL2': -55.192917, 'AcHPPL_BHDL2': -57.424792, 'ACSEPL_BHADLA': -46.548542, 'ADHPL': -183.939167, 'AEGFPL_BHDL2': -14.366458, 'AEGSPL_BHDL2': -28.983333, 'AHEJ2L_S_FTG2': -60.041667,
    'AHEJ2L_W_FTG2': -46.489583, 'AHEJ3L_S_FTG2': -67.03125, 'AHEJ3L_W_FTG2': -44.90625, 'AHEJ4L_S_FTG1': -97.09375, 'AHEJ4L_W_FTG1': -320.625, 'AHEJOL_S_FTG2': -80.156979, 'AHEJOL_W_FTG2': -57.375, 'ANTA_CRF': 0,
    'ANTA_GF': 0, 'ANTA_LF': 0, 'ANTA_RF': -35.525833, 'ANTA_SOLAR': -9.792812, 'AP41PL_BHDL': -61.818958, 'AP43PL_BKN': -71.552083, 'APIPL': -33.625, 'APMPL_BHDL': -57.822917, 'APTFPL_Bhadla': -25.208333, 'ARERJL': -39.921875,
    'ARP1PL_BKN': -46.347292, 'ARP3PL_BKN': -14.189167, 'ARP3PL_BKN_INF': -29.343333, 'ARTPL_BKN2': -29.171875, 'ASE4PL': -9.932292, 'ASEJ2L': -11.822917, 'ASEJ2PL_BKN': -17.5, 'ASEJ2PLP2_BKN': -26.927083, 'ASEJOPL_S_FTG2': -81,
    'ASEJOPL_W_FTG2': -67.083333, 'ASERJ2PL_BHDL': -27.415625, 'ASERJ2PL_FTG2': -45.865833, 'ASERJ2PL_FTG2_INF': -4.241042, 'ASunceEPL_BKN': -40.270833, 'AURAIYA_SOLAR': -7.729583, 'AURY_CRF': 0, 'AURY_GF': 0, 'AURY_LF': 0,
    'AURY_RF': -56.337188, 'AvRJHNPL_BKN': -27.375, 'AvSEPL_BHDL2': -55.520833, 'AvSusRJPPL_BKN': -34.572917, 'AXPPL_FTG3': -75.239688, 'BHAKRA': -1116.25, 'BSIUL': 0, 'BUDHIL': -46.268333, 'CHAMERA1': -533.52, 'CHAMERA2': -66.0375,
    'CHAMERA3': -42.793125, 'CSP_Bhadla': -65.052083, 'CSPJPL_BHDL': -45.407188, 'DADRI_CRF': 0, 'DADRI_GF': 0, 'DADRI_LF': 0, 'DADRI_RF': -61.889792, 'DADRI_SOLAR': -0.753125, 'DADRIT': -349.928371, 'DADRT2': -542.101688,
    'DEHAR': -259.583333, 'DHAULIGNGA': -278.875, 'DSNTPC_FTG2': -50.94375, 'DULHASTI': -380.15625, 'ERCPL_FTG2': -63.130521, 'GEPL_BKN2': -25.619792, 'JHAJJAR': -861.011645, 'KISHANGANGA': -330.75, 'KOLDAM': -872, 'KOTESHWR': -338.985258,
    'KSPPNL_BHDL2': -73.952188, 'KWHEP': -1126.441979, 'MSRPL_BHDL': -50.393646, 'MSUPL_BHDL2': -46.612292, 'NAPP': -371, 'NJPC': -1617.3125, 'NOKHRANT_BHDL2': -62.315104, 'NSNTPC_FTG1': -61.307396, 'OVEPL_BKN2': -25.5125,
    'PARBATI3': -62.8125, 'PONG': -59.625, 'RAMPUR': -439.4375, 'RAPPB': -332, 'RAPPC': -405, 'RENEW_Bhadla': -10.880625, 'RIHAND1': -830.418255, 'RIHAND2': -848.025994, 'RIHAND3': -854.796462, 'RSAPL_FTG3': -60.145938,
    'RSBPL_FTG2': -59.665521, 'RSEJ3PL_FTG2': -61.775312, 'RSEKPL_BHDL2': -39.519062, 'RSPPL_BKN': -42.265208, 'RSPPL_FTG3': -54.375, 'RSRPL_BKN': -60.984375, 'RSRPL_FTG3': -70.9075, 'RSUPL_FTG2': -57.599375, 'RSVPL_FTG3': -18.913125,
    'RSWPL3_FTG2': -58.509479, 'SAINJ': -44.666667, 'SALAL': -677.5, 'SBE6PL': -60.989583, 'SBEFPL_Bhadla': -38.765625, 'SBSRPC11PL_BKN': 0, 'SCLTPS': -209.621771, 'SEWA2': -71.63, 'SINGOLI': -4.436458, 'SINGRAULI': -1476.830776,
    'SINGRAULI_HYDRO': -5.3125, 'SINGRAULI_SOLAR': -1.514688, 'SORANG_HEP': -72.072917, 'SRI4PL_BKN2': -34.072917, 'SRI4PL_BKN2_INF': 0, 'TANAKPUR': -79.166667, 'TANDA2': -916.113126, 'TEHRI': -886.463346, 'TESPL_BKN2': -25.742708,
    'TGEPL_BKN2': -16.177083, 'TPGEL_BKN': -28.936458, 'TPREL': -57.1625, 'TPSL_BKN': -13.909375, 'TPSL_BKN2': -38.978333, 'TPSL_BKN2_INF': -18.698958, 'TS1PL_BKN': -36.1875, 'TSESPL_BKN2': -8.083333, 'UNCHAHAR_SOLAR': -1.539167,
    'UNCHAHAR1': -214.385826, 'UNCHAHAR2': -259.766525, 'UNCHAHAR3': -63.343199, 'UNCHAHAR4': -323.11375, 'URI': -286.510417, 'URI2': -151.854167, 'VAE_NR': -623.242404, 'VSCED_NR': 256.992396
}

# Split data into labels and values
labels = list(data.keys())
values = list(data.values())

# Create the plot
# plt.figure(figsize=(2000, 10))
# plt.barh(values, labels, color='skyblue')
# plt.xlabel('Average Value')
# plt.ylabel('Plant Name')
# plt.title('Graph Showing Average Values of Different Plants')

# # Show the graph
# plt.show()

# plt.figure(figsize=(15, 6))
# plt.bar(labels, values)
# plt.xticks(rotation=90)  # Rotate x-axis labels by 90 degrees
# plt.xlabel('Power Plants')
# plt.ylabel('Average Value')
# plt.title('Average Data of Power Plants')
# plt.tight_layout()  # Adjust layout so labels don't get cut off
# plt.show()
#---------------------------
plt.figure(figsize=(20, 6))
plt.bar(labels, values)

plt.xticks(rotation=90)

plt.xlabel('Power Plants')
plt.ylabel('Average Value (Log Scale)')
plt.title('Average Data of Power Plants')
plt.tight_layout()
plt.show()



