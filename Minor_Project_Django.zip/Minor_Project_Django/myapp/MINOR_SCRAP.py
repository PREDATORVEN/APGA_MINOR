from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time
import datetime 
from datetime import date
import base64
from PIL import Image
import pytesseract
from pytesseract import pytesseract
import pymongo
import pandas as pd
import os ,glob,shutil
import win32com.client as win32
from flask import Flask ,jsonify
import pyperclip ,pyautogui
path_to_tesseract = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
cap_one_sub_but=5
# DATE SELECTION FUNCTION!!
'''
def date_setting(today,driver):
    target_date = str(today)
    driver.find_element(By.ID, "scheduleDate").click()
    targetlst = target_date.split("-")
    todaylst = today.split("-")
    today = todaylst[2] + "-" + todaylst[1] + "-" + todaylst[0]
    target_date = targetlst[2] + "-" + targetlst[1] + "-" + targetlst[0]

    if (today.split("-")[1] != target_date.split("-")[1]):
        driver.find_element(By.XPATH, "/html/body/div[3]/div/a[2]").click()

    tble = driver.find_element(By.XPATH, '/html/body/div[3]/table/tbody')
    tareekh = tble.find_elements(By.TAG_NAME, 'td')

    no_date = 0
    for tr in tareekh:
        if tr.text not in [str(item) for item in range(1, 10)]:
            if (tr.text == target_date[0:2]):
                no_date += 1
        else:
            if ('0' + tr.text == target_date[0:2]):
                no_date += 1

    for tr in tareekh:
        if tr.text not in [str(item) for item in range(1, 10)]:
            if (tr.text == target_date[0:2]) and no_date == 1:
                tr.click()
                break
            elif (tr.text == target_date[0:2]) and no_date == 2:
                no_date = 1
        else:
            if ('0' + tr.text == target_date[0:2]):
                tr.click()
                break
# ---------------------------------------------
'''
def date_setting(search_Date,driver):
    target_date = str(search_Date)
    targetlst = target_date.split("-")
    proc_target_date = targetlst[2] + "-" + targetlst[1] + "-" + targetlst[0]
    print(proc_target_date)
    
    # date_tbn.send_keys(proc_target_date)
    date_tbn=driver.find_element(By.XPATH, "/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[1]/div[2]/div/input").click()
    pyautogui.hotkey('ctrl','a')
    time.sleep(2)
    pyautogui.hotkey('ctrl','x')
    time.sleep(2)
    date_text=pyperclip.copy(proc_target_date)
    time.sleep(2)
    pyautogui.hotkey('ctrl','v')
    driver.find_element(By.XPATH,"/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div[1]").click()
    

#Captcha One Bypass Function!!
def Captcha_one(driver):
    global cap_one_sub_but
    # Show Data Button
    driver.find_element(By.ID, 'SubmitBtn').click()
    time.sleep(5)

     # Selecting image and taking screenshot
    img_ele = driver.find_element(By.XPATH, '//*[@id="ShowCaptchaBox"]/div/div/div/img')
    time.sleep(2)
    ss = img_ele.screenshot_as_base64
    time.sleep(2)
    print("screen shot taken for captcha 1!!")

    # Bypassing Captcha one
    png_screenshot = base64.b64decode(ss)
    with open('D:\\YASH STUFF\\Python\\Web_Scrappers\\Revised_WebScrapping\\captcha_one.jpg', 'wb') as f:
        f.write(png_screenshot)
    print("captcha 1 SAVED !!")
    image_path = r"D:\YASH STUFF\Python\Web_Scrappers\Revised_WebScrapping\captcha_one.jpg"  
    img = Image.open(image_path)
    pytesseract.tesseract_cmd = path_to_tesseract
    text_one = pytesseract.image_to_string(img)
    print("captcha 1 :",text_one)
    captcha_field = driver.find_element(By.ID, 'txtCaptcha') 
    captcha_field.send_keys(text_one)
    time.sleep(2)
    print("Captcha_one entered !!")

    # Clicking the submit button
    driver.find_element(By.XPATH, f'/html/body/div[{cap_one_sub_but}]/div[3]/div/button/span').click()
    time.sleep(30)
    # Handling Wrong Captcha!!
    res_element=driver.find_element(By.ID,"shareDivContent")
    res_response=res_element.text
    return res_response
    

#----------------------------------------------

#
def Iterate_Captcha_one(res_response):
   
    global cap_one_sub_but
    if(res_response=='''"Invalid Captcha"'''):
        time.sleep(5)
        print("INVALID CAPTCHA")
        cap_one_sub_but+=1
        value=Captcha_one()
        Iterate_Captcha_one(value)
    else:
        print("VALID CAPTCHA")
        time.sleep(5)
        print("DATA DISPLAYED!!")    
#----------------------------------------------

#Captcha Two
def Captcha_Two(driver):
    # Clicking the download button
    driver.find_element(By.XPATH,'/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div[1]/div[2]/a/i').click()
    time.sleep(2)

    # Clicking the excel button    
    driver.find_element(By.ID, 'CsvExport').click()
    time.sleep(2)

    # Screenshot 
    img_ele2=driver.find_element(By.XPATH,"/html/body/div[5]/div[2]/div/div/div/img")
    time.sleep(2)
    ss=img_ele2.screenshot_as_base64
    time.sleep(2)
    # Bypassing Captcha one
    png_screenshot = base64.b64decode(ss)
    with open('D:\\YASH STUFF\\Python\\Web_Scrappers\\Revised_WebScrapping\\captcha_two.jpg', 'wb') as f:
        f.write(png_screenshot)
    print("captcha 1 SAVED !!")
    image_path = r"D:\YASH STUFF\Python\Web_Scrappers\Revised_WebScrapping\captcha_two.jpg"  
    img = Image.open(image_path)
    pytesseract.tesseract_cmd = path_to_tesseract
    text_one = pytesseract.image_to_string(img)
    print("captcha 2 :",text_one)
    captcha_field = driver.find_element(By.ID, 'txtCaptcha') 
    captcha_field.send_keys(text_one)
    time.sleep(2)
    print("Captcha_two entered !!")

    driver.find_element(By.XPATH,"/html/body/div[5]/div[3]/div/button").click()
    time.sleep(30)

   

#----------------------------------------------
#Mongodb Data Insertion
def Insert_DB(File_Path,today):
    client=pymongo.MongoClient("mongodb://localhost:27017/")
    df=pd.read_csv(fr"{File_Path}")
    # df['Date']=today
    df.insert(0,"Date",today)
    print("-_-_-"*10)
    print(df.head())
    print("-_-_-"*10)
    print(df.tail())
    print("-_-_-"*10)
    data=df.to_dict(orient="records")
    
    db=client["Minor_Project"]
    db.NET_SCHEDULE.insert_many(data)
    time.sleep(2)
    print("DATA INSERTED INTO DATABASE!!")

#----------------------------------------------
# DRIVER CODE FOR SCRAPING!!
def launch(today):
    chrome_options = webdriver.ChromeOptions()
    prefs = {
    "download.default_directory": r"D:\YASH STUFF\Minor_Project\File_Downloads",  # Set the download directory
    "download.prompt_for_download": False,  # Disable download prompts
    "directory_upgrade": True  # Overwrite existing download directory
    }
    chrome_options.add_experimental_option("prefs", prefs)

# Initialize the Chrome WebDriver with the modified options
    driver = webdriver.Chrome(options=chrome_options)

    # driver=webdriver.Chrome()
    driver.get("https://wbes.nrldc.in/ReportNetSchedule/GetNetScheduleIndex")
    time.sleep(5)

    # today="2024-08-01";
    date_setting(today,driver)
    time.sleep(15)
    element=driver.find_element(By.ID,"lblCreatedOnField")
    Created_Date=element.text
    if(len(Created_Date)!= 0):
        # Region Dropdown
        region1 = driver.find_element(By.ID, 'ddlRegion')
        drop_down1 = Select(region1)
        drop_down1.select_by_visible_text('NORTH')
        time.sleep(2)

        # Buyer DropDown
        region3 = driver.find_element(By.ID, 'ddl_Seller')
        drop_down3 = Select(region3)
        drop_down3.select_by_visible_text('ALL')
        time.sleep(5)

        # # captcha one 
        # res_response=Captcha_one(driver)
        # Iterate_Captcha_one(res_response)
        
        #captcha two
        Captcha_Two(driver)

        curr_url=driver.current_url
        if(curr_url=="https://wbes.nrldc.in/ReportNetSchedule/GetNetScheduleIndex#"):
            print("Captcha Passed")
            time.sleep(20)

            # Scanning the Downloads folder for latest file to be dumped into the Mongodb
            # downloads_folder=r"C:\Users\Yash Sharma\Downloads"
            downloads_folder=r"D:\YASH STUFF\Minor_Project\File_Downloads"

            csv_files=glob.glob(os.path.join(downloads_folder,"*.csv")) 

            csv_files.sort(key=os.path.getmtime,reverse=True)  # Descending Order!!

            if("NetSchedule-Summary-ALL_Seller" in csv_files[0]):
                File_Path=csv_files[0]

                excel=win32.Dispatch('Excel.Application')
                excel.Visible=True
                excel.DisplayAlerts=False
                wb=excel.Workbooks.Open(File_Path)
                wb.SaveAs(File_Path, FileFormat=6)
                wb.Close(SaveChanges=True)
                excel.Quit()

                Insert_DB(File_Path,today)
               
            #----------------------------------------------------------------------------
            else:
                print("Couldn't Find the Desired File!!")
        else:
            print("Captcha Failed")
            launch(today)
        



        
    else:
        print("No Data Found on : ",today)
        print(len(Created_Date))
#----------------------------------------------

def delete_folder_content(folder_path):
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)  # Delete the file or link
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)  # Delete the directory
        except Exception as e:
            print(f'Failed to delete {file_path}. Reason: {e}')
    
def main():
    # today=str(input("ENTER DATE(eg: 2024-08-01): "))
    f1=open(r"D:\YASH STUFF\Minor_Project\Minor_Project_Django\date_minor_log.txt","r")
    down_folder_path=r"D:\YASH STUFF\Minor_Project\File_Downloads"
    today=f1.read()
    delete_folder_content(down_folder_path)
    launch(today)

if __name__=='__main__':
    main()

