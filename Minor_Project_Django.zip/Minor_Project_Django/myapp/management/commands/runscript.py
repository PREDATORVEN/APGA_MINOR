from django.core.management.base import BaseCommand
from myapp.MINOR_SCRAP import main

class Command(BaseCommand):
    help = 'Runs the web scraping script'

    def handle(self, *args, **kwargs):
        # Place your script logic here
        print('Running web scraping script...')
        main()
        