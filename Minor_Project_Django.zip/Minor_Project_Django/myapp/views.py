from django.shortcuts import render
from django.http import JsonResponse ,HttpResponse
import subprocess
from pymongo import MongoClient
import time,os,glob
import json


# Create your views here.

#Mongo db details!!
client=MongoClient("mongodb://localhost:27017/")
db=client["Minor_Project"]
collection=db["NET_SCHEDULE"]
#

def home(request):
    return render(request,'myapp/home_new.html')

def web_scrape_window(request):
    return render(request ,'myapp/Web_Scrape.html')


def date_extract(request):
    if request.method == "POST":
        value=request.POST.get("scrp_date")
        f1=open("D:\YASH STUFF\Minor_Project\Minor_Project_Django\date_minor_log.txt","w+")
        f1.write(value)
        f1.seek(0)
        value2=f1.readline()
        f1.close()
        response=run_scrape(request)
        

        return HttpResponse(f"STATUS: File downloaded at {response }")
            
            



    
def run_scrape(request):
    batch_file_path=r"D:\YASH STUFF\Minor_Project\Snippets_minor\minor_batch.bat"
        
    try:
        # Run the batch file and show terminal window
        subprocess.Popen(batch_file_path, shell=True, creationflags=subprocess.CREATE_NEW_CONSOLE)
        time.sleep(5)
        flag=1
        while(flag==1):
            folder_path=r"D:\YASH STUFF\Minor_Project\File_Downloads"
            csv_files=glob.glob(os.path.join(folder_path,"*.csv")) 
            if(len(csv_files)!=0):
                flag=0
                csv_files.sort(key=os.path.getmtime,reverse=True)  # Descending Order!!
                if("NetSchedule-Summary-ALL_Seller" in csv_files[0]):
                    File_Path=csv_files[0]


        return(File_Path)
    except Exception as e:
        return(f"An error occurred: {e}")



def data_retrieve():
    data=list(collection.distinct('Date'))
    return data

def history_window(request):
    scrape_data=data_retrieve()
    return render(request,"myapp/History.html",{'scrape_data':scrape_data})

def date_data_retrieve(date):
    data=list(collection.find({'Date':date},{'_id':0}))
    json_data=json.dumps(data)
    return json_data
def date_detail_info(request):
        date=request.GET.get('selected_date')
        data=date_data_retrieve(date)
        return render(request,"myapp/Date_detail.html",{'data':data,'selected_date':date})
