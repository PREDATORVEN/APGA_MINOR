document.getElementById("btn_scrape").onclick=function(){
    var ele=document.createElement("input");
    ele.setAttribute("type" ,"text");
    ele.setAttribute("name" ,"field_date");
    document.getElementById("container").appendChild(ele);
    

}
// function run_scrape(){

// }

function run_api(){
    window.location.href="/run-api/"
}