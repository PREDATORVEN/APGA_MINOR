"""Minor_Project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from myapp import views 
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home,name='home'),
    path('web_scrape/',views.web_scrape_window,name='web_scrape'),
    path('web_scrape/form_date/',views.date_extract,name='form_date'),
    path('history/',views.history_window,name='history'),
    path('date_detail/',views.date_detail_info,name='date_detail'),
]
